#' HPD sets based on empirical probabilities of counts
#'
#' This function computes HPD sets based on empirical probabilities of counts.
#'
#'
#' @param x A vector of realizations of count data from its posterior distribution.
#' @param conf The desired confidence level; defaults to 0.90.
#'
#' @details This function is often applied to compute the highest posterior density sets when we have realizations of count data from its posterior distribution (results from an MCMC run), but can also be applied to any distribution of count data, including priors.
#'
#' The values returned will be conservative (i.e., too wide rather than too narrow), and will be unstable if few values are provided.
#' @references
#' \insertRef{Mere:Krus:2020}{NbBvs}
#'
#' @return  A vector of all the elements of the interval.
#'
#' @examples
#' x <- rpois(10000, 10) # random draw from a Poisson distribution
#' emp.hpd(x)
#'
#' @export
emp.hpd <- function(x, conf = 0.90){
  table.x <- table(x) / length(x)
  m <- order(table.x, decreasing = TRUE)
  table.x <- table.x[m]
  xx <- as.numeric(rownames(table.x))
  nnn <- min(which(cumsum(table.x) >= conf))
  xx[seq(nnn)]
}
