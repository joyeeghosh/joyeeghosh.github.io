#' Negative Binomial regression model using SSVS approach for prediction
#'
#' This function implements Negative Binomial regression model using SSVS approach with missing predictors via JAGS, for prediction.
#'
#'
#' @param d Index of rows on which the response is predicted.
#' @param X  Data frame of design matrix (not standardized) without the column corresponding to the intercept. All code assumes that an intercept will be included in each model and the variables without missing values are put in the front.
#' @param y  Vector of response variables.
#' @param niter  Number of MCMC iterations; defaults to 1e+06.
#' @param burnin  Number of samples in burn-in; defaults to 15,000.
#' @param n.thin  Thinning degree; defaults to n.thin = 10, i.e., we keep every 10th value.
#' @param rho  Inclusion probability (same for all predictors); defaults to rho = 0.5 for discrete uniform.
#' If specified to NA (rho = NA), the Gibbs sampler will use Beta prior for rho.
#' @param (h_a,h_b)  Hyper-parameters of the alternative Beta prior for rho.
#' @param k3 Shape parameter for Gamma prior on precision for second level of the model for covariates; defauls to 1.
#' @param k4 Rate parameter for Gamma prior on precision for second level of the model for covariates; defauls to 1/5.
#' @param lm0 Prior variance for Normal prior on the intercept; defauls to 100.
#' @param lm Prior variance for Normal prior component for other regression coefficients; defauls to 1.
#' @param r0 Upper limit for Uniform prior on NB dispersion parameter; defauls to 1000.
#' @param impute  Indicator for whether to sample covariate values from posterior predictive distribution when covariate values are unavailable at time of prediction; defaults to TRUE.
#' @param order  Ordering of covariates; defaults to order = NULL for no user-specified ordering and determined by missing rate.
#' @details This function implements SSVS approach in Negative Binomial regression model with missing predictors for prediction. If some of the covariates are missing/unobserved at the time of prediction, this function by default retain all covariates in the model; sample the unobserved covariates from their predictive distribution; and marginalize over them using Monte Carlo integration.
#'
#' The ordering of covariates is going to have an impact on the joint distribution in the second level as the covariates may not be fully observed.
#'
#' If not specified by the user, this function by default orders variables by the percentage of missing values so that variables with the least missing values appear first.
#'
#' For the choice of the hyper-parameters (h_a, h_b) of the alternative Beta prior for rho, \insertCite{Li:2013;textual}{NbBvs} recommends (h_a=1, h_b=p^c) for higher dimensional cases, where c takes value between 0 and 1. More discussion could be found in \insertCite{Scot:Berg:2010;textual}{NbBvs}.
#' @references
#' \insertRef{Scot:Berg:2010}{NbBvs}
#'
#' \insertRef{Li:2013}{NbBvs}
#' @examples
#' #########################################################
#' #########################################################
#' ## The code below can be used to generate and analyze  ##
#' ## one dataset under scenario 1 of the simulation from ##
#' ## Section 4.4 of Li, Ghosh, and Villarini             ##
#' #########################################################
#' #########################################################
#' set.seed(13)
#' library(mvtnorm)
#' library(mcmcse)
#' sig <- matrix(0,12,12)
#' diag(sig) <- 0.5
#' for (i in 1:12) {sig[i,i] <- 1}
#' sig[1,2] <- 0.7;  sig[2,1] <- 0.7 # sst obs atl and trop
#' sig[1,3] <- 0.9; sig[3,1] <- 0.9 # sst obs atl and gfdla atl
#' sig[1,4] <- 0.7; sig[4,1] <- 0.7 # sst obs atl and gfdla trop
#' sig[2,4] <- 0.7; sig[4,2] <- 0.7 # sst obs trop and gfdla trop
#' sig[3,4] <- 0.7; sig[4,3] <- 0.7 # gfdla atl and gfdla trop
#' sig[2,3] <- 0.6; sig[3,2] <- 0.6 # sst obs trop and gfdla atl
#' X <- rmvnorm(n=100,mean=rep(0,12),sigma=sig)
#' mu.pois <- exp(cbind(1,X[,1:4])%*%c(1.8,0.4,-0.2,0.35,-0.25))
#' y <- rpois(n=100,lambda=mu.pois)
#'
#' true.y.pred <- y[51:100] # Store the actual values of y which will be predicted
#' X.miss <- X
#' X.miss[51:100, 1:2] <- NA # X1 and X2 are unavailable for the last 50 observations
#'
#' ##################################################
#' ########### Method 1 (Retain/Impute) #############
#' ##################################################
#'
#' system.time(sim1 <- NbBvs_pred(d=c(51:100), X = X.miss, y = y, niter = 100000, burnin = 20000,
#' n.thin = 10, rho = 0.5, impute = TRUE))
#'
#' med <- apply(sim1,2,function(x){mcse.q(x,q=0.5)$est})
#' rmse <- sqrt(mean((med - true.y.pred)^2))
#' mae <- mean(abs(med - true.y.pred))
#' perc.5 <- apply(sim1,2,function(x){mcse.q(x,q=0.05)$est})
#' perc.95 <- apply(sim1,2,function(x){mcse.q(x,q=0.95)$est})
#' cov.equaltail <- mean(true.y.pred >= perc.5 & true.y.pred <= perc.95)
#' size.equaltail <- mean(perc.95 - perc.5 + 1)
#' cov.hpd <- mean(apply(rbind(true.y.pred,sim1),2,function(x){x[1]%in%emp.hpd(x[-1])}))
#' size.hpd <- mean(apply(sim1,2,function(x){length(emp.hpd(x))}))
#' cor.pearson <- cor(med,true.y.pred,method="pearson")
#' cor.spearman <- cor(med,true.y.pred,method="spearman")
#' scen1.m1 <- c(cor.pearson,cor.spearman,rmse,mae,cov.hpd,cov.equaltail,size.hpd,size.equaltail)
#'
#' ############################################
#' ########### Method 2 (Discard) #############
#' ############################################
#'
#' system.time(sim2 <- NbBvs_pred(d=c(51:100), X = X.miss, y = y, niter = 100000, burnin = 20000,
#' n.thin = 10, rho = 0.5, impute = FALSE))
#'
#' med <- apply(sim2,2,function(x){mcse.q(x,q=0.5)$est})
#' rmse <- sqrt(mean((med - true.y.pred)^2))
#' mae <- mean(abs(med - true.y.pred))
#' perc.5 <- apply(sim2,2,function(x){mcse.q(x,q=0.05)$est})
#' perc.95 <- apply(sim2,2,function(x){mcse.q(x,q=0.95)$est})
#' cov.equaltail <- mean(true.y.pred >= perc.5 & true.y.pred <= perc.95)
#' size.equaltail <- mean(perc.95 - perc.5 + 1)
#' cov.hpd <- mean(apply(rbind(true.y.pred,sim2),2,function(x){x[1]%in%emp.hpd(x[-1])}))
#' size.hpd <- mean(apply(sim2,2,function(x){length(emp.hpd(x))}))
#' cor.pearson <- cor(med,true.y.pred,method="pearson")
#' cor.spearman <- cor(med,true.y.pred,method="spearman")
#' scen1.m2 <- c(cor.pearson,cor.spearman,rmse,mae,cov.hpd,cov.equaltail,size.hpd,size.equaltail)
#'
#' ###################################################
#' ### Full dataset (all covariates are available) ###
#' ###################################################
#'
#' system.time(sim <- NbBvs_pred(d=c(51:100), X = X, y = y, niter = 100000, burnin = 20000,
#' n.thin = 10, rho = 0.5, impute = FALSE))
#'
#' med <- apply(sim,2,function(x){mcse.q(x,q=0.5)$est})
#' rmse <- sqrt(mean((med - true.y.pred)^2))
#' mae <- mean(abs(med - true.y.pred))
#' perc.5 <- apply(sim,2,function(x){mcse.q(x,q=0.05)$est})
#' perc.95 <- apply(sim,2,function(x){mcse.q(x,q=0.95)$est})
#' cov.equaltail <- mean(true.y.pred >= perc.5 & true.y.pred <= perc.95)
#' size.equaltail <- mean(perc.95 - perc.5 + 1)
#' cov.hpd <- mean(apply(rbind(true.y.pred,sim),2,function(x){x[1]%in%emp.hpd(x[-1])}))
#' size.hpd <- mean(apply(sim,2,function(x){length(emp.hpd(x))}))
#' cor.pearson <- cor(med,true.y.pred,method="pearson")
#' cor.spearman <- cor(med,true.y.pred,method="spearman")
#' scen1.full <- c(cor.pearson,cor.spearman,rmse,mae,cov.hpd,cov.equaltail,size.hpd,size.equaltail)
#'
#' Note: this example is included for illustrative purposes.
#' To replicate the simulation in Li, Ghosh, and Villarini, change niter to 5,000,000.
#'
#' @return  MCMC samples from posterior predictive distribution of y as a matrix.
#' @export
NbBvs_pred <- function(d, X = X, y = y, niter = 1000000, burnin = 15000, n.thin = 10, rho = 0.5, h_a, h_b, k3 = 1, k4 = 1/5, lm0 = 100, lm = 1, r0 = 1000, impute = TRUE, order = NULL)
{

  X.m <- 1 * (!is.na(X))  # Matrix with binary entries: 0 for missing covariate value, 1 for observed covariate value
  X.M <- apply(X.m, 1, sum) # Vector that gives the number of observed predictor values in each row
  if (is.null(order)){
    miss.X <- colSums(is.na(X))
    ordering <- order(miss.X, decreasing = FALSE)
    X <- X[, ordering] # Reorder predictors by their missing rate
  }else{
    ordering <- order
    X <- X[, ordering]
  }
  # If rho = NA, set it equal to to (h_a, h_b) parametrization
  if(is.na(rho)){
    if(any(X.M[d] != dim(X)[2]))
    {  # If missingness in covariates in vector d (years to be predicted)
      if (impute == TRUE)
      {
        n <- dim(X)[1]   # number of observations
        X <- cbind(rep(1, n), X)
        p <- dim(X)[2]   # number of predictors plus intercept
        X.mis <- 1 * (!is.na(X))  # Matrix with binary entries (including the intercept): 0 for missing covariate value, 1 for observed covariate value
        for (t in 1 : p)
        { # Replace the missing value by column mean to start with
          X[is.na(X[, t]), t] <- mean(X[, t], na.rm = TRUE)
        }
        ## Set hyperparameters for Gamma prior on precision for second level of the model for covariates ##
        k3 <- k3 # shape
        k4 <- k4 # rate
        ## Set hyperparameters for Normal prior component for regression coefficients ##
        lm0 <- lm0 # prior variance
        lm <- lm # prior variance

        ### NbBvs: Function for JAGS that defines likelihood and prior ###
        NbBvs <- function( )
        {
          ## Likelihood ##
          for (i in 1 : n)
          {
            Y[i] ~ dnegbin(q[i],r)
            q[i] <- 1/(1 + lambda[i])
            log(lambda[i]) <- mu[i]
            mu[i] <- inprod(beta[ ],X[i, ])
            X[i,2] ~ dnorm(theta[1, 1], psi[1]) # Note psi is precision = 1/variance of normal distribution
            for (j in 3 : p)
            {
              X[i,j] ~  dnorm(inprod(theta[(j-1), 1:(j-1)], X[i, 1:(j-1)]), psi[j-1])
            }
          }
          ## Priors ##
          rho ~ dbeta(h_a, h_b) # beta prior on the inclusion probability (same for all predictors)
          beta[1] ~ dnorm(0, 1/lm0) # prior on intercept for top level
          for (j in 2 : p)
          {
            beta[j] <- beta1[j - 1] * delta[j - 1] # Mixture of point mass at 0 and normal prior on reg coefficients
            beta1[j-1] ~ dnorm(0, 1/lm)  # Normal component of the above prior
            delta[j - 1] ~ dbern(rho) # Indicator of which prior component is selected (normal vs. point mass at 0)
            psi[j-1] ~ dgamma(k3, k4) # Put a gammma prior on the precision in second level model for covariates
            theta[(j-1), 1] ~ dnorm(0, psi[j-1]/lm0) # prior on intercept for second level
            for (l in 2 : (p - 1))
            {
              theta[(j-1), l] ~ dnorm(0, psi[j-1]/lm)  # Put a normal prior on the regression cofficients in second level of model
            }
          }
          r ~ dunif(0, r0) # Uniform prior on NB dispersion parameter
        }


        ######################################################
        ### Prepare initial values and data for JAGS ###
        ######################################################
        # d = Index of rows on which the response is predicted
        # Yi.d and Xi are initial values of Y and X for JAGS
        # numbers as initial values for entries where Y and X are sampled; NAs where values are obseved (so not sampled)

        #### Begin:  Assign intital Values of X and Y ######
        Yi.d <- rep(NA, length = n)
        Yi.d[d] <- 1  #1s are initial values where entries of Y are predicted, NAs for observed response values

        Xi <- matrix(NA, ncol = p, nrow = n)
        Xi[X.mis == 0] <- 1 # 1s are initial covariate values that are to be sampled, NAs for observed covariate values
        #### End:  Assign intital Values of X and Y ######

        ### Initial values for JAGS ###
        valin <- function(){
          list("theta" =  matrix(rep(0, (p-1) * (p-1)), ncol = p - 1) , "psi" = rep(1, p - 1), "beta1" = rep(0, p-1),
               "delta" = rep(0, p-1), "X" = Xi, "Y" = Yi.d, "r" = 500, "rho" = 0.5)
        }

        ### Center and scale the design matrix without entries in d ###
        ## X.full: Design matrix with first column of 1s; other columns standardized with mean/sd wihout rows in d
        X.full <- X
        mean.X <- apply(X.full[-d, -1], 2, mean, na.rm = TRUE)
        sd.X <- apply(X.full[-d, -1], 2, sd, na.rm = TRUE)
        X.full[, -1] <- scale(X.full[, -1], center = mean.X, scale = sd.X)
        X.full[X.mis == 0] <- NA # Fill entries with NAs where covariate values are to be sampled for JAGS data step

        Y.d <- y
        Y.d[d] <- NA # Fill entries with NAs where response values are to be sampled for JAGS data step

        ### Data for JAGS ###
        dat <- list("X" = X.full, "Y" = Y.d, "p"= p,  "n" = n, "k3" = k3, "k4" = k4, "lm0" = lm0, "lm" = lm, "r0" = r0, "h_a" = h_a, "h_b" = h_b)   # names list of numbers

        ### Parameters to be saved ###
        #prmtr <- c("Y", "beta", "psi", "theta", "r", "X")   # full list takes up too much memory
        prmtr <- c("Y", "beta")   # Y and beta to be saved by default

        #### Begin: CALL JAGS #########
        jfit <- R2jags::jags(data = dat, inits = valin, parameters.to.save = prmtr, model.file = NbBvs,
                             n.chains = 1, n.iter = niter, n.burnin = burnin, n.thin = n.thin,
                             DIC = TRUE, working.directory = NULL, jags.seed = 123, refresh = 500,progress.bar = "text", digits = 5)
        #### End: CALL JAGS #########

        output <- jfit$BUGSoutput
        outlist <- output$sims.list
        Ypred <- outlist$Y[, d]   # MCMC samples of Y
        result <- Ypred
        #result <- cbind(apply(Ypred, 2, mean), apply(Ypred, 2, function(x) quantile(x, 0.5)), apply(Ypred, 2, function(x) quantile(x, 0.05)), apply(Ypred, 2, function(x) quantile(x, 0.95)), apply(Ypred, 2, function(x) mcse.q(x, 0.05)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.5)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.95)$se))
      }
      else if (impute == FALSE) {  #  If the missing values are to be discarded
        missing_c <- which(apply(X.m[, ordering][d, ], 2, sum) == 0) # Find the column indices with entirely missing values
        X <- X[, -missing_c] # Remove the predictors which are missing from the design matrix

        n <- dim(X)[1]   # number of  observations
        X <- cbind(rep(1, n), X)
        p <- dim(X)[2]   # number of predictors plus intercept
        X.mis <- 1 * (!is.na(X)) # Matrix with binary entries (including the intercept): 0 for missing covariate value, 1 for observed covariate value
        for (t in 1 : p){ # Replace the missing value by column mean to start with
          X[is.na(X[, t]), t] <- mean(X[, t], na.rm = TRUE)
        }

        ## Set hyperparameters for Gamma prior on precision for second level of the model for covariates ##
        k3 <- k3 # shape
        k4 <- k4 # rate
        ## Set hyperparameters for Normal prior component for regression coefficients ##
        lm0 <- lm0 # prior variance
        lm <- lm # prior variance

        ### NbBvs: Function for JAGS that defines likelihood and prior ###
        NbBvs <- function( )
        {
          ## Likelihood ##
          for(i in 1 : n)
          {
            Y[i] ~ dnegbin(q[i],r)
            q[i] <- 1/(1+lambda[i])
            log(lambda[i]) <- mu[i]
            mu[i] <- inprod(beta[],X[i,])
            X[i,2] ~ dnorm(theta[1,1], psi[1]) # Note psi is precision = 1/variance of normal distribution
            for (j in 3 : p)
            {
              X[i,j] ~  dnorm(inprod(theta[(j-1),1:(j-1)],X[i,1:(j-1)]),psi[j-1])
            }
          }
          ## Priors ##
          rho ~ dbeta(h_a, h_b) # beta prior on the inclusion probability (same for all predictors)
          beta[1] ~ dnorm(0, 1/lm0) # prior on intercept for top level
          for (j in 2 : p)
          {
            beta[j] <- beta1[j - 1] * delta[j - 1] # Mixture of point mass at 0 and normal prior on reg coefficients
            beta1[j-1] ~ dnorm(0, 1/lm) # Normal component of the above prior
            delta[j - 1] ~ dbern(rho) # Indicator of which prior component is selected (normal vs. point mass at 0)
            psi[j-1] ~ dgamma(k3, k4) # Put a gamma prior on the precision
            theta[(j-1), 1] ~ dnorm(0, psi[j-1]/lm0) # prior on intercept for second level
            for (l in 2 : (p - 1))
            {
              theta[(j-1), l] ~ dnorm(0, psi[j-1]/lm) # Put a normal prior on the regression cofficients in second level of model
            }
          }
          r ~ dunif(0, r0) # Uniform prior on NB dispersion parameter
        }

        ######################################################
        ### Prepare initial values and data for JAGS ###
        ######################################################
        # d = Index of rows on which the response is predicted
        # Yi.d and Xi are initial values of Y and X for JAGS
        # numbers as initial values for entries where Y and X are sampled; NAs where values are obseved (so not sampled)

        #### Begin:  Assign intital Values of X and Y ######
        Yi.d <- rep(NA, length = n)
        Yi.d[d] <- 1  #1s are initial values where entries of Y are predicted, NAs for observed response values

        Xi <- matrix(NA, ncol = p, nrow = n)
        Xi[X.mis == 0] <- 1 # 1s are initial covariate values that are to be sampled, NAs for observed covariate values
        #### End:  Assign intital Values of X and Y ######

        ### Initial values for JAGS ###
        valin<-function(){
          list("theta" =  matrix(rep(0, (p-1) * (p-1)), ncol = p - 1) , "psi" = rep(1, p - 1), "beta1" = rep(0, p-1),
               "delta" = rep(0, p-1), "X" = Xi, "Y" = Yi.d, "r" = 500, "rho" = 0.5)
        }
        ### Center and scale the design matrix without entries in d ###
        ## X.full: Design matrix with first column of 1s; other columns standardized with mean/sd wihout rows in d
        X.full <- X
        mean.X <- apply(X.full[-d, -1], 2, mean, na.rm = TRUE)
        sd.X <- apply(X.full[-d, -1], 2, sd, na.rm = TRUE)
        X.full[, -1] <- scale(X.full[, -1], center = mean.X, scale = sd.X)
        X.full[X.mis == 0] <- NA # Fill entries with NAs where covariate values are to be sampled for JAGS data step

        Y.d <- y
        Y.d[d] <- NA # Fill entries with NAs where response values are to be sampled for JAGS data step

        ### Data for JAGS ###
        dat <- list("X" = X.full, "Y" = Y.d, "p"= p, "n" = n, "k3" = k3, "k4" = k4, "lm0" = lm0, "lm" = lm, "r0" = r0, "h_a" = h_a, "h_b" = h_b)   # names list of numbers

        ### Parameters to be saved ###
        #prmtr <- c("Y", "beta", "psi", "theta", "r", "X")   # full list takes up too much memory
        prmtr <- c("Y", "beta")   # Y and beta to be saved by default

        #### Begin: CALL JAGS #########
        jfit <- R2jags::jags(data = dat,inits = valin, parameters.to.save = prmtr, model.file = NbBvs,
                             n.chains = 1, n.iter = niter, n.burnin = burnin, n.thin = n.thin,
                             DIC = TRUE, working.directory = NULL,jags.seed = 123,refresh = 500, progress.bar = "text", digits = 5)
        #### End: CALL JAGS #########

        output <- jfit$BUGSoutput
        outlist <- output$sims.list
        Ypred <- outlist$Y[, d]   # MCMC samples of Y
        result <- Ypred
        #result <- cbind(apply(Ypred, 2, mean), apply(Ypred, 2, function(x) quantile(x, 0.5)), apply(Ypred, 2, function(x) quantile(x, 0.05)), apply(Ypred, 2, function(x) quantile(x, 0.95)), apply(Ypred, 2, function(x) mcse.q(x, 0.05)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.5)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.95)$se))
      }
    }

    else{  # if no missing values in d
      n <- dim(X)[1]   # number of observations
      X <- cbind(rep(1, n), X)
      p <- dim(X)[2]   # number of predictors plus intercept
      X.mis <- 1 * (!is.na(X))  # Matrix with binary entries (including the intercept): 0 for missing covariate value, 1 for observed covariate value
      for (t in 1 : p)
      { # Replace the missing value by column mean to start with
        X[is.na(X[, t]), t] <- mean(X[, t], na.rm = TRUE)
      }
      ## Set hyperparameters for Gamma prior on precision for second level of the model for covariates ##
      k3 <- k3 # shape
      k4 <- k4 # rate
      ## Set hyperparameters for Normal prior component for regression coefficients ##
      lm0 <- lm0 # prior variance
      lm <- lm # prior variance

      ### NbBvs: Function for JAGS that defines likelihood and prior ###
      NbBvs <- function( )
      {
        ## Likelihood ##
        for (i in 1 : n)
        {
          Y[i] ~ dnegbin(q[i],r)
          q[i] <- 1/(1 + lambda[i])
          log(lambda[i]) <- mu[i]
          mu[i] <- inprod(beta[ ],X[i, ])
          X[i,2] ~ dnorm(theta[1, 1], psi[1]) # Note psi is precision = 1/variance of normal distribution
          for (j in 3 : p)
          {
            X[i,j] ~  dnorm(inprod(theta[(j-1), 1:(j-1)], X[i, 1:(j-1)]), psi[j-1])
          }
        }
        ## Priors ##
        rho ~ dbeta(h_a, h_b) # beta prior on the inclusion probability (same for all predictors)
        beta[1] ~ dnorm(0, 1/lm0) # prior on intercept for top level
        for (j in 2 : p)
        {
          beta[j] <- beta1[j - 1] * delta[j - 1] # Mixture of point mass at 0 and normal prior on reg coefficients
          beta1[j-1] ~ dnorm(0, 1/lm)  # Normal component of the above prior
          delta[j - 1] ~ dbern(rho) # Indicator of which prior component is selected (normal vs. point mass at 0)
          psi[j-1] ~ dgamma(k3, k4) # Put a gammma prior on the precision in second level model for covariates
          theta[(j-1), 1] ~ dnorm(0, psi[j-1]/lm0) # prior on intercept for second level
          for (l in 2 : (p - 1))
          {
            theta[(j-1), l] ~ dnorm(0, psi[j-1]/lm)  #Put a normal prior on the regression cofficients in second level of model
          }
        }
        r ~ dunif(0, r0) # Uniform prior on NB dispersion parameter
      }
      ######################################################
      ### Prepare initial values and data for JAGS ###
      ######################################################
      # d = Index of rows on which the response is predicted
      # Yi.d and Xi are initial values of Y and X for JAGS
      # numbers as initial values for entries where Y and X are sampled; NAs where values are obseved (so not sampled)

      #### Begin:  Assign intital Values of X and Y ######
      Yi.d <- rep(NA, length = n)
      Yi.d[d] <- 1  #1s are initial values where entries of Y are predicted, NAs for observed response values

      Xi <- matrix(NA, ncol = p, nrow = n)
      Xi[X.mis == 0] <- 1 # 1s are initial covariate values that are to be sampled, NAs for observed covariate values
      #### End:  Assign intital Values of X and Y ######

      ### Initial values for JAGS ###
      valin <- function(){
        list("theta" =  matrix(rep(0, (p-1) * (p-1)), ncol = p - 1) , "psi" = rep(1, p - 1), "beta1" = rep(0, p-1),
             "delta" = rep(0, p-1), "X" = Xi, "Y" = Yi.d, "r" = 500, "rho" = 0.5)
      }

      ### Center and scale the design matrix without entries in d ###
      ## X.full: Design matrix with first column of 1s; other columns standardized with mean/sd wihout rows in d
      X.full <- X
      mean.X <- apply(X.full[-d, -1], 2, mean, na.rm = TRUE)
      sd.X <- apply(X.full[-d, -1], 2, sd, na.rm = TRUE)
      X.full[, -1] <- scale(X.full[, -1], center = mean.X, scale = sd.X)
      X.full[X.mis == 0] <- NA # Fill entries with NAs where covariate values are to be sampled for JAGS data step

      Y.d <- y
      Y.d[d] <- NA # Fill entries with NAs where response values are to be sampled for JAGS data step

      ### Data for JAGS ###
      dat <- list("X" = X.full, "Y" = Y.d, "p"= p,  "n" = n, "k3" = k3, "k4" = k4, "lm0" = lm0, "lm" = lm, "r0" = r0, "h_a" = h_a, "h_b" = h_b)   # names list of numbers

      ### Parameters to be saved ###
      #prmtr <- c("Y", "beta", "psi", "theta", "r", "X")   # full list takes up too much memory
      prmtr <- c("Y", "beta")   # Y and beta to be saved by default

      #### Begin: CALL JAGS #########
      jfit <- R2jags::jags(data = dat, inits = valin, parameters.to.save = prmtr, model.file = NbBvs,
                           n.chains = 1, n.iter = niter, n.burnin = burnin, n.thin = n.thin,
                           DIC = TRUE, working.directory = NULL, jags.seed = 123, refresh = 500,progress.bar = "text", digits = 5)
      #### End: CALL JAGS #########

      output <- jfit$BUGSoutput
      outlist <- output$sims.list
      Ypred <- outlist$Y[, d]   # MCMC samples of Y
      result <- Ypred
      #result <- cbind(apply(Ypred, 2, mean), apply(Ypred, 2, function(x) quantile(x, 0.5)), apply(Ypred, 2, function(x) quantile(x, 0.05)), apply(Ypred, 2, function(x) quantile(x, 0.95)), apply(Ypred, 2, function(x) mcse.q(x, 0.05)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.5)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.95)$se))
    }
  }
  else
  {
    if(any(X.M[d] != dim(X)[2]))
    {  # If missingness in covariates in vector d (years to be predicted)
      if (impute == TRUE)
      {
        n <- dim(X)[1]   # number of observations
        X <- cbind(rep(1, n), X)
        p <- dim(X)[2]   # number of predictors plus intercept
        X.mis <- 1 * (!is.na(X))  # Matrix with binary entries (including the intercept): 0 for missing covariate value, 1 for observed covariate value
        for (t in 1 : p)
        { # Replace the missing value by column mean to start with
          X[is.na(X[, t]), t] <- mean(X[, t], na.rm = TRUE)
        }
        ## Set hyperparameters for Gamma prior on precision for second level of the model for covariates ##
        k3 <- k3 # shape
        k4 <- k4 # rate
        ## Set hyperparameters for Normal prior component for regression coefficients ##
        lm0 <- lm0 # prior variance
        lm <- lm # prior variance

        ### NbBvs: Function for JAGS that defines likelihood and prior ###
        NbBvs <- function( )
        {
          ## Likelihood ##
          for (i in 1 : n)
          {
            Y[i] ~ dnegbin(q[i],r)
            q[i] <- 1/(1 + lambda[i])
            log(lambda[i]) <- mu[i]
            mu[i] <- inprod(beta[ ],X[i, ])
            X[i,2] ~ dnorm(theta[1, 1], psi[1]) # Note psi is precision = 1/variance of normal distribution
            for (j in 3 : p)
            {
              X[i,j] ~  dnorm(inprod(theta[(j-1), 1:(j-1)], X[i, 1:(j-1)]), psi[j-1])
            }
          }
          ## Priors ##
          beta[1] ~ dnorm(0, 1/lm0) # prior on intercept for top level
          for (j in 2 : p)
          {
            beta[j] <- beta1[j - 1] * delta[j - 1] # Mixture of point mass at 0 and normal prior on reg coefficients
            beta1[j-1] ~ dnorm(0, 1/lm)  # Normal component of the above prior
            delta[j - 1] ~ dbern(rho) # Indicator of which prior component is selected (normal vs. point mass at 0)
            psi[j-1] ~ dgamma(k3, k4) # Put a gammma prior on the precision in second level model for covariates
            theta[(j-1), 1] ~ dnorm(0, psi[j-1]/lm0) # prior on intercept for second level
            for (l in 2 : (p - 1))
            {
              theta[(j-1), l] ~ dnorm(0, psi[j-1]/lm)  #Put a normal prior on the regression cofficients in second level of model
            }
          }
          r ~ dunif(0, r0) # Uniform prior on NB dispersion parameter
        }


        ######################################################
        ### Prepare initial values and data for JAGS ###
        ######################################################
        # d = Index of rows on which the response is predicted
        # Yi.d and Xi are initial values of Y and X for JAGS
        # numbers as initial values for entries where Y and X are sampled; NAs where values are obseved (so not sampled)

        #### Begin:  Assign intital Values of X and Y ######
        Yi.d <- rep(NA, length = n)
        Yi.d[d] <- 1  #1s are initial values where entries of Y are predicted, NAs for observed response values

        Xi <- matrix(NA, ncol = p, nrow = n)
        Xi[X.mis == 0] <- 1 # 1s are initial covariate values that are to be sampled, NAs for observed covariate values
        #### End:  Assign intital Values of X and Y ######

        ### Initial values for JAGS ###
        valin <- function(){
          list("theta" =  matrix(rep(0, (p-1) * (p-1)), ncol = p - 1) , "psi" = rep(1, p - 1), "beta1" = rep(0, p-1),
               "delta" = rep(0, p-1), "X" = Xi, "Y" = Yi.d, "r" = 500)
        }

        ### Center and scale the design matrix without entries in d ###
        ## X.full: Design matrix with first column of 1s; other columns standardized with mean/sd wihout rows in d
        X.full <- X
        mean.X <- apply(X.full[-d, -1], 2, mean, na.rm = TRUE)
        sd.X <- apply(X.full[-d, -1], 2, sd, na.rm = TRUE)
        X.full[, -1] <- scale(X.full[, -1], center = mean.X, scale = sd.X)
        X.full[X.mis == 0] <- NA # Fill entries with NAs where covariate values are to be sampled for JAGS data step

        Y.d <- y
        Y.d[d] <- NA # Fill entries with NAs where response values are to be sampled for JAGS data step

        ### Data for JAGS ###
        dat <- list("X" = X.full, "Y" = Y.d, "p"= p,  "n" = n, "k3" = k3, "k4" = k4, "lm0" = lm0, "lm" = lm, "rho" = rho, "r0" = r0)   # names list of numbers

        ### Parameters to be saved ###
        #prmtr <- c("Y", "beta", "psi", "theta", "r", "X")   # full list takes up too much memory
        prmtr <- c("Y", "beta")   # Y and beta to be saved by default

        #### Begin: CALL JAGS #########
        jfit <- R2jags::jags(data = dat, inits = valin, parameters.to.save = prmtr, model.file = NbBvs,
                             n.chains = 1, n.iter = niter, n.burnin = burnin, n.thin = n.thin,
                             DIC = TRUE, working.directory = NULL, jags.seed = 123, refresh = 500,progress.bar = "text", digits = 5)
        #### End: CALL JAGS #########

        output <- jfit$BUGSoutput
        outlist <- output$sims.list
        Ypred <- outlist$Y[, d]   # MCMC samples of Y
        result <- Ypred
        #result <- cbind(apply(Ypred, 2, mean), apply(Ypred, 2, function(x) quantile(x, 0.5)), apply(Ypred, 2, function(x) quantile(x, 0.05)), apply(Ypred, 2, function(x) quantile(x, 0.95)), apply(Ypred, 2, function(x) mcse.q(x, 0.05)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.5)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.95)$se))
      }
      else if (impute == FALSE) {  #  If the missing values are to be discarded
        missing_c <- which(apply(X.m[, ordering][d, ], 2, sum) == 0) # Find the column indices with entirely missing values
        X <- X[, -missing_c] # Remove the predictors which are missing from the design matrix

        n <- dim(X)[1]   # number of  observations
        X <- cbind(rep(1, n), X)
        p <- dim(X)[2]   # number of predictors plus intercept
        X.mis <- 1 * (!is.na(X)) # Matrix with binary entries (including the intercept): 0 for missing covariate value, 1 for observed covariate value
        for (t in 1 : p){ # Replace the missing value by column mean to start with
          X[is.na(X[, t]), t] <- mean(X[, t], na.rm = TRUE)
        }

        ## Set hyperparameters for Gamma prior on precision for second level of the model for covariates ##
        k3 <- k3 # shape
        k4 <- k4 # rate
        ## Set hyperparameters for Normal prior component for regression coefficients ##
        lm0 <- lm0 # prior variance
        lm <- lm # prior variance

        ### NbBvs: Function for JAGS that defines likelihood and prior ###
        NbBvs <- function( )
        {
          ## Likelihood ##
          for(i in 1 : n)
          {
            Y[i] ~ dnegbin(q[i],r)
            q[i] <- 1/(1+lambda[i])
            log(lambda[i]) <- mu[i]
            mu[i] <- inprod(beta[],X[i,])
            X[i,2] ~ dnorm(theta[1,1], psi[1]) # Note psi is precision = 1/variance of normal distribution
            for (j in 3 : p)
            {
              X[i,j] ~  dnorm(inprod(theta[(j-1),1:(j-1)],X[i,1:(j-1)]),psi[j-1])
            }
          }
          ## Priors ##
          beta[1] ~ dnorm(0, 1/lm0) # prior on intercept for top level
          for (j in 2 : p)
          {
            beta[j] <- beta1[j - 1] * delta[j - 1] # Mixture of point mass at 0 and normal prior on reg coefficients
            beta1[j-1] ~ dnorm(0, 1/lm) # Normal component of the above prior
            delta[j - 1] ~ dbern(rho) # Indicator of which prior component is selected (normal vs. point mass at 0)
            psi[j-1] ~ dgamma(k3, k4) # Put a gamma prior on the precision
            theta[(j-1), 1] ~ dnorm(0, psi[j-1]/lm0) # prior on intercept for second level
            for (l in 2 : (p - 1))
            {
              theta[(j-1), l] ~ dnorm(0, psi[j-1]/lm) # Put a normal prior on the regression cofficients in second level of model
            }
          }
          r ~ dunif(0, r0) # Uniform prior on NB dispersion parameter
        }

        ######################################################
        ### Prepare initial values and data for JAGS ###
        ######################################################
        # d = Index of rows on which the response is predicted
        # Yi.d and Xi are initial values of Y and X for JAGS
        # numbers as initial values for entries where Y and X are sampled; NAs where values are obseved (so not sampled)

        #### Begin:  Assign intital Values of X and Y ######
        Yi.d <- rep(NA, length = n)
        Yi.d[d] <- 1  #1s are initial values where entries of Y are predicted, NAs for observed response values

        Xi <- matrix(NA, ncol = p, nrow = n)
        Xi[X.mis == 0] <- 1 # 1s are initial covariate values that are to be sampled, NAs for observed covariate values
        #### End:  Assign intital Values of X and Y ######

        ### Initial values for JAGS ###
        valin<-function(){
          list("theta" =  matrix(rep(0, (p-1) * (p-1)), ncol = p - 1) , "psi" = rep(1, p - 1), "beta1" = rep(0, p-1),
               "delta" = rep(0, p-1), "X" = Xi, "Y" = Yi.d, "r" = 500)
        }
        ### Center and scale the design matrix without entries in d ###
        ## X.full: Design matrix with first column of 1s; other columns standardized with mean/sd wihout rows in d
        X.full <- X
        mean.X <- apply(X.full[-d, -1], 2, mean, na.rm = TRUE)
        sd.X <- apply(X.full[-d, -1], 2, sd, na.rm = TRUE)
        X.full[, -1] <- scale(X.full[, -1], center = mean.X, scale = sd.X)
        X.full[X.mis == 0] <- NA # Fill entries with NAs where covariate values are to be sampled for JAGS data step

        Y.d <- y
        Y.d[d] <- NA # Fill entries with NAs where response values are to be sampled for JAGS data step

        ### Data for JAGS ###
        dat <- list("X" = X.full, "Y" = Y.d, "p"= p, "n" = n, "k3" = k3, "k4" = k4, "lm0" = lm0, "lm" = lm, "rho" = rho, "r0" = r0)   # names list of numbers

        ### Parameters to be saved ###
        #prmtr <- c("Y", "beta", "psi", "theta", "r", "X")   # full list takes up too much memory
        prmtr <- c("Y", "beta")   # Y and beta to be saved by default

        #### Begin: CALL JAGS #########
        jfit <- R2jags::jags(data = dat,inits = valin, parameters.to.save = prmtr, model.file = NbBvs,
                             n.chains = 1, n.iter = niter, n.burnin = burnin, n.thin = n.thin,
                             DIC = TRUE, working.directory = NULL,jags.seed = 123,refresh = 500, progress.bar = "text", digits = 5)
        #### End: CALL JAGS #########

        output <- jfit$BUGSoutput
        outlist <- output$sims.list
        Ypred <- outlist$Y[, d]   # MCMC samples of Y
        result <- Ypred
        #result <- cbind(apply(Ypred, 2, mean), apply(Ypred, 2, function(x) quantile(x, 0.5)), apply(Ypred, 2, function(x) quantile(x, 0.05)), apply(Ypred, 2, function(x) quantile(x, 0.95)), apply(Ypred, 2, function(x) mcse.q(x, 0.05)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.5)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.95)$se))
      }
    }

    else{  # if no missing values in d
      n <- dim(X)[1]   # number of observations
      X <- cbind(rep(1, n), X)
      p <- dim(X)[2]   # number of predictors plus intercept
      X.mis <- 1 * (!is.na(X))  # Matrix with binary entries (including the intercept): 0 for missing covariate value, 1 for observed covariate value
      for (t in 1 : p)
      { # Replace the missing value by column mean to start with
        X[is.na(X[, t]), t] <- mean(X[, t], na.rm = TRUE)
      }
      ## Set hyperparameters for Gamma prior on precision for second level of the model for covariates ##
      k3 <- k3 # shape
      k4 <- k4 # rate
      ## Set hyperparameters for Normal prior component for regression coefficients ##
      lm0 <- lm0 # prior variance
      lm <- lm # prior variance

      ### NbBvs: Function for JAGS that defines likelihood and prior ###
      NbBvs <- function( )
      {
        ## Likelihood ##
        for (i in 1 : n)
        {
          Y[i] ~ dnegbin(q[i],r)
          q[i] <- 1/(1 + lambda[i])
          log(lambda[i]) <- mu[i]
          mu[i] <- inprod(beta[ ],X[i, ])
          X[i,2] ~ dnorm(theta[1, 1], psi[1]) # Note psi is precision = 1/variance of normal distribution
          for (j in 3 : p)
          {
            X[i,j] ~  dnorm(inprod(theta[(j-1), 1:(j-1)], X[i, 1:(j-1)]), psi[j-1])
          }
        }
        ## Priors ##
        beta[1] ~ dnorm(0, 1/lm0) # prior on intercept for top level
        for (j in 2 : p)
        {
          beta[j] <- beta1[j - 1] * delta[j - 1] # Mixture of point mass at 0 and normal prior on reg coefficients
          beta1[j-1] ~ dnorm(0, 1/lm)  # Normal component of the above prior
          delta[j - 1] ~ dbern(rho) # Indicator of which prior component is selected (normal vs. point mass at 0)
          psi[j-1] ~ dgamma(k3, k4) # Put a gammma prior on the precision in second level model for covariates
          theta[(j-1), 1] ~ dnorm(0, psi[j-1]/lm0) # prior on intercept for second level
          for (l in 2 : (p - 1))
          {
            theta[(j-1), l] ~ dnorm(0, psi[j-1]/lm)  #Put a normal prior on the regression cofficients in second level of model
          }
        }
        r ~ dunif(0, r0) # Uniform prior on NB dispersion parameter
      }
      ######################################################
      ### Prepare initial values and data for JAGS ###
      ######################################################
      # d = Index of rows on which the response is predicted
      # Yi.d and Xi are initial values of Y and X for JAGS
      # numbers as initial values for entries where Y and X are sampled; NAs where values are obseved (so not sampled)

      #### Begin:  Assign intital Values of X and Y ######
      Yi.d <- rep(NA, length = n)
      Yi.d[d] <- 1  #1s are initial values where entries of Y are predicted, NAs for observed response values

      Xi <- matrix(NA, ncol = p, nrow = n)
      Xi[X.mis == 0] <- 1 # 1s are initial covariate values that are to be sampled, NAs for observed covariate values
      #### End:  Assign intital Values of X and Y ######

      ### Initial values for JAGS ###
      valin <- function(){
        list("theta" =  matrix(rep(0, (p-1) * (p-1)), ncol = p - 1) , "psi" = rep(1, p - 1), "beta1" = rep(0, p-1),
             "delta" = rep(0, p-1), "X" = Xi, "Y" = Yi.d, "r" = 500)
      }

      ### Center and scale the design matrix without entries in d ###
      ## X.full: Design matrix with first column of 1s; other columns standardized with mean/sd wihout rows in d
      X.full <- X
      mean.X <- apply(X.full[-d, -1], 2, mean, na.rm = TRUE)
      sd.X <- apply(X.full[-d, -1], 2, sd, na.rm = TRUE)
      X.full[, -1] <- scale(X.full[, -1], center = mean.X, scale = sd.X)
      X.full[X.mis == 0] <- NA # Fill entries with NAs where covariate values are to be sampled for JAGS data step

      Y.d <- y
      Y.d[d] <- NA # Fill entries with NAs where response values are to be sampled for JAGS data step

      ### Data for JAGS ###
      dat <- list("X" = X.full, "Y" = Y.d, "p"= p,  "n" = n, "k3" = k3, "k4" = k4, "lm0" = lm0, "lm" = lm, "rho" = rho, "r0" = r0)   # names list of numbers

      ### Parameters to be saved ###
      #prmtr <- c("Y", "beta", "psi", "theta", "r", "X")   # full list takes up too much memory
      prmtr <- c("Y", "beta")   # Y and beta to be saved by default

      #### Begin: CALL JAGS #########
      jfit <- R2jags::jags(data = dat, inits = valin, parameters.to.save = prmtr, model.file = NbBvs,
                           n.chains = 1, n.iter = niter, n.burnin = burnin, n.thin = n.thin,
                           DIC = TRUE, working.directory = NULL, jags.seed = 123, refresh = 500,progress.bar = "text", digits = 5)
      #### End: CALL JAGS #########

      output <- jfit$BUGSoutput
      outlist <- output$sims.list
      Ypred <- outlist$Y[, d]   # MCMC samples of Y
      result <- Ypred
      #result <- cbind(apply(Ypred, 2, mean), apply(Ypred, 2, function(x) quantile(x, 0.5)), apply(Ypred, 2, function(x) quantile(x, 0.05)), apply(Ypred, 2, function(x) quantile(x, 0.95)), apply(Ypred, 2, function(x) mcse.q(x, 0.05)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.5)$se), apply(Ypred, 2, function(x) mcse.q(x, 0.95)$se))
    }
    }

  return(result)
}



